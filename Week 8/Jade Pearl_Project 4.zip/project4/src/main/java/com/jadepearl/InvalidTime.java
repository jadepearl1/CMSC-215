package com.jadepearl;

public class InvalidTime extends Exception {
    public InvalidTime(String message) {
        super(message);
    }
}
