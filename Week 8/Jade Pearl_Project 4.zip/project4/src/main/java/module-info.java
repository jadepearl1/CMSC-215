module com.jadepearl {
    requires javafx.controls;
    requires transitive javafx.graphics;
    exports com.jadepearl;
}
