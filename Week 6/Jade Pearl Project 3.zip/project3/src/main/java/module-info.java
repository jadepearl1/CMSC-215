module com.jadepearl {
    requires javafx.controls;
    exports com.jadepearl;
}
